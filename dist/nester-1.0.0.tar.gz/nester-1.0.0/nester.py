def print_lol(list_movies, level):
    for movies in list_movies:
        if isinstance(movies, list):
                print_lol(movies, level+1)
        else:
            for tab_stop in range(level):
               print("\t", end='')
            print(movies)
            
